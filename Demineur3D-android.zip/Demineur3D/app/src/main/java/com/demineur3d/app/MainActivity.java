package com.demineur3d.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.splashscreen.SplashScreen;
import androidx.webkit.WebViewAssetLoader;

/**
 * Démineur 3D — conteneur natif Android.
 *
 * Le jeu (assets/demineur.html) est entièrement autonome (aucune API distante ;
 * seules les polices Google sont chargées en ligne, avec repli système hors-ligne).
 * Il est servi via WebViewAssetLoader sur le domaine virtuel
 * https://appassets.androidplatform.net/ afin de garantir une origine HTTPS réelle
 * (localStorage fiable pour les statistiques, meilleurs temps, séries…).
 *
 * Choix « jeu » :
 *   - Écran de démarrage (SplashScreen API) jusqu'au chargement.
 *   - Écran maintenu allumé pendant la partie (FLAG_KEEP_SCREEN_ON).
 *   - PAS de « tirer pour rafraîchir » (réinitialiserait la partie en cours).
 *   - Survit à la rotation sans redémarrer (configChanges dans le manifeste) :
 *     la partie n'est pas perdue quand on tourne l'écran.
 *   - Double appui sur Retour pour quitter (évite de fermer le jeu par erreur).
 */
public class MainActivity extends Activity {

    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL  = "https://" + APP_HOST + "/assets/demineur.html";

    private WebView webView;
    private boolean contentReady = false;
    private long lastBackPress = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen splash = SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);

        splash.setKeepOnScreenCondition(() -> !contentReady);
        new Handler(Looper.getMainLooper()).postDelayed(() -> contentReady = true, 3500);

        // Garder l'écran allumé pendant le jeu
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                // Les assets locaux passent par l'AssetLoader ; tout le reste (polices Google) en réseau normal.
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri url = request.getUrl();
                if (APP_HOST.equals(url.getHost())) return false;   // contenu interne -> WebView
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url)); // lien externe éventuel -> navigateur
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                contentReady = true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                 // localStorage : stats, meilleurs temps, séries
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false); // moteur audio synthétisé (Web Audio)
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
}
