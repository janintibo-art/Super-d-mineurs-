# 💣 Démineur 3D — APK Android

Jeu de démineur en **3D (CSS)** multi-couches, avec moteur audio synthétisé, joystick de navigation, statistiques, séries et 4 difficultés. Empaqueté en application Android native (WebView) à compiler via **GitHub Actions** (aucun outil à installer en local).

## 🎮 Le jeu
- **3D multi-couches** (perspective CSS), navigation joystick + zoom.
- **4 difficultés** : Easy 8×8 (10 mines), Med 12×12 (24), Hard 16×16 (40), Giant 24×24 (99).
- **Audio synthétisé** (pistes + effets), **chording** (clic accord), drapeaux / points d'interrogation.
- **Statistiques** persistantes (parties, victoires, meilleurs temps, séries).
- 100 % **autonome** : aucune API distante (seules les polices Google se chargent en ligne, repli système hors-ligne).

## 🆕 Améliorations de cette version
- **💡 Indice** (3 par partie) : met en surbrillance une case **sûre** sans la révéler — un coup de pouce quand on bloque, sans gâcher le défi.
- **🎉 Confettis** à la victoire.
- **Réglages mémorisés** : difficulté, **mode** et **musique** retrouvés d'une session à l'autre.
- **Vibration** : « boum » à l'explosion 💥 et motif de **victoire** 🎉 (+ léger retour au drapeau).
- **Mémorisation de la difficulté** choisie d'une session à l'autre.
- **Conteneur Android orienté jeu** : écran **maintenu allumé**, **survit à la rotation** sans perdre la partie, **pas** de « tirer pour rafraîchir » (qui réinitialiserait le jeu), permission *vibreur*, double-appui Retour pour quitter.

## 🛠️ Compiler l'APK (GitHub Actions)
Deux fichiers suffisent dans le dépôt : ce **projet** et un **workflow**. Voir le workflow fourni :
il décompresse le zip puis lance `gradle assembleDebug`. À la fin, récupère l'artifact **`Demineur3D-debug`** → `app-debug.apk`.

> Le `gradle-wrapper.jar` est volontairement absent : il est **régénéré** côté CI.

## ⚙️ Détails techniques
- WebView + `WebViewAssetLoader` (origine HTTPS virtuelle `https://appassets.androidplatform.net/`) pour un `localStorage` fiable (sauvegarde des stats).
- AGP 8.5.2 · Gradle 8.7 · compileSdk 34 · minSdk 24 · JDK 17.
- `applicationId` / namespace : `com.demineur3d.app`.
- APK *debug* (usage personnel) — aucune signature requise.
